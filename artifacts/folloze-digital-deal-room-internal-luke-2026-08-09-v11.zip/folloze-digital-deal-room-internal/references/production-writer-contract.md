# Production Writer Contract

Use the bundled production writer for every native Folloze board mutation. The writer is account-neutral: it receives resolved buyer-safe values and local asset paths through a closed JSON specification, and it must never contain account-specific constants or receive raw transcripts, credentials, cookies, arbitrary commands, or connector payloads.

## Responsibility boundary

The writer owns deterministic Folloze API work:

1. Audit the exact allowlisted template and authenticated organization.
2. Copy the template and checkpoint the new Board ID immediately.
3. Confirm that the copied board is not a template.
4. Apply buyer-safe metadata and validate the requested vanity slug.
5. Upload independent files concurrently.
6. Create or update board-specific Essentials and example items without mutating shared source items.
7. Apply the template adapter's allowlisted logo, hero, Essentials, value-text, and example mutations.
8. Prove the ROI HTML is byte-identical and the value-widget change is text-only.
9. Strip transient scripts, recompute the designer-compatible hash, save, and read back.
10. Publish only when every required asset and structural gate passes and the write specification authorizes publishing.
11. Return a compact receipt containing Board ID, operation checkpoints, item IDs, hashes, publication state, vanity URL, and blockers.

Codex owns connector-bound work outside the writer:

- Salesforce opportunity and owner resolution
- Google Sheets tracker reads and updates
- Google Drive tile resolution and shared-library uploads
- authenticated browser editor invitation and visual QA
- Slack review notification

Materialize only compact connector evidence for later receipt composition. Each required connector action must carry its real source (`google_sheets`, `google_drive`, `folloze_api`, `authenticated_browser`, or `slack`), `verified=true`, and a connector-native evidence ID or receipt SHA-256. Boolean success claims without independent connector evidence must fail final verification. A spawned Node process cannot call Codex MCP connectors, so do not disguise those actions as local writer commands.

## Commands

Use `capabilities` during preflight. It is read-only and must emit a bounded machine receipt ending with `DSR_WRITER_CAPABILITIES_JSON_END`.

```bash
node scripts/fast_path_writer.js capabilities
```

Validate a resolved write specification without Folloze writes:

```bash
node scripts/fast_path_writer.js plan --spec WRITE_SPEC.json
```

Apply only after preflight succeeds. Require the exact run ID, durable state path, explicit external-write authorization, and one receipt path:

```bash
node scripts/fast_path_writer.js apply \
  --spec WRITE_SPEC.json \
  --confirm-run-id RUN_ID \
  --state RUN.writer-state.json \
  --receipt RUN.writer-receipt.json \
  --allow-external-writes
```

Credentials come only from the explicitly selected Folloze auth profile or inherited authorized environment. Never place them in the specification, state, receipt, logs, or command arguments.

## Idempotency and failure behavior

- Bind writer state to both `run_id` and the normalized specification hash.
- Checkpoint the copied Board ID before any later mutation.
- Checkpoint every uploaded asset, created item, saved hash, vanity result, and publish result immediately after success.
- On resume, re-read and verify a checkpoint before reusing it. Never infer completion from a local state flag alone.
- Never retry the whole writer after a partial external write. Retry only a known transient operation whose idempotency is proven.
- If the writer stops after board creation, report the Board ID and highest verified nonterminal state. Do not delete or publish it automatically.
- Keep the copied board private until publish readiness and explicit publish authorization are both true.

## Release gate

Do not package or distribute the skill unless all of these pass:

- writer capabilities receipt
- closed-spec validation and secret rejection
- mocked template audit, copy polling, upload, config save, vanity, and publish tests
- ROI and value-widget structural guards
- partial-run resume without duplicate boards or items
- blocked preflight producing zero Folloze writes
- orchestrator ordering and parsed-receipt validation
- existing final receipt verifier tests

The first live test after a writer change must be a read-only template audit. A disposable copied-board canary requires explicit authorization and must remain unpublished until its readback gates pass.
