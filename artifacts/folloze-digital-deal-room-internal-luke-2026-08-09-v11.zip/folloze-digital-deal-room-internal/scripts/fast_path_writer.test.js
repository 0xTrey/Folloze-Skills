"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { spawnSync } = require("node:child_process");

const { copyTemplate, findBoardId, parseArgs, runWriter } = require("./fast_path_writer.js");
const { FollozeClient } = require("./lib/folloze_client.js");
const { WIDGETS } = require("./lib/template_248623.js");

const TEMPLATE_NAME = "Folloze Resource Center / Digital Deal Room Template - July 2026 Folloze Resource Center";

function templateConfig() {
  const cards = Array.from({ length: 4 }, (_, index) =>
    `<article><span>label-${index}-old</span><h3>heading-${index}-old</h3><p>body-${index}-old</p><strong>proof-${index}-old</strong><svg><text>protected-${index}</text></svg></article>`
  ).join("");
  return {
    meta: { originHash: "origin", newHash: "template" },
    pages: {
      default: {
        sections: {},
        widgets: {
          [WIDGETS.header]: {
            data: {
              secondary_logo: { image: {}, size: "small", type: "manual" },
              visibility: {},
              navigation: { items: [
                { text: "Example Boards", action: { anchor: { hash: "examples" } } },
                { text: "ROI Calculator", action: { anchor: { hash: "roi" } } },
              ] },
            },
          },
          [WIDGETS.hero]: { data: { visibility: {} } },
          [WIDGETS.essentials]: { data: { visibility: {} } },
          [WIDGETS.value]: { data: { content: `<style>.x{content:"intro-old"}</style><h2>From brief to live campaign. In minutes, not sprints.</h2><p>intro-old</p>${cards}` } },
          [WIDGETS.examples]: { data: { sources: {} } },
          [WIDGETS.roi]: { data: { content: "<h2>Estimate potential pipeline and revenue.</h2><script>protected()</script>" } },
        },
      },
    },
  };
}

function makeFiles(root) {
  const files = {};
  for (const name of ["recording.mp4", "recording.png", "deck.pdf", "deck.png", "order-form.pdf", "order-form.png", "example.png"]) {
    const file = path.join(root, name);
    fs.writeFileSync(file, `fresh-${name}`);
    files[name] = file;
  }
  return files;
}

function makeSpec(files, overrides = {}) {
  const cardIds = ["build_speed_scalability", "personalization_enrichment", "analytics_optimization", "operational_scale_reuse"];
  const spec = {
    schema_version: "1.0",
    run_id: "writer-test-001",
    target: {
      base_url: "https://app.folloze.com",
      profile: "engage",
      organization_id: 2,
      template: { id: 248623, name: TEMPLATE_NAME },
    },
    board: { name: "Example | Folloze Resource Center", description: "A buyer safe resource center.", slug: "example-resource-center", publish: true },
    brand: { company_name: "Example", logo_url: "https://example.com/logo.svg", accent_hex: "#12AB34" },
    copy: {
      hero_subtitle: "Explore how Folloze helps Example scale relevant buyer engagement.",
      essentials_intro: "Start with the platform recording and presentation.",
      value_section: {
        ai_signal_present: false,
        section_subheader: { from: "intro-old", to: "A call-informed operating path." },
        cards: cardIds.map((id, index) => ({
          id,
          label: { from: `label-${index}-old`, to: `label-${index}-new` },
          heading: { from: `heading-${index}-old`, to: `heading-${index}-new` },
          body: { from: `body-${index}-old`, to: `body-${index}-new` },
          proof: { from: `proof-${index}-old`, to: `proof-${index}-new` },
        })),
      },
    },
    assets: {
      recording: { path: files["recording.mp4"], cover_path: files["recording.png"], title: "Example + Folloze | Platform Demo", description: "Watch the edited platform demo." },
      deck: { path: files["deck.pdf"], cover_path: files["deck.png"], title: "Example + Folloze | Presentation", description: "Review the account presentation." },
    },
    examples: [{ board_id: 123456, title: "Example Campaign", description: "Explore a verified campaign.", url: "https://experience.folloze.com/example-campaign", slug: "example-campaign", tile_path: files["example.png"] }],
  };
  return { ...spec, ...overrides };
}

class FakeClient {
  constructor() {
    this.identity = { issuer: "https://app.folloze.com", subject: "42", organization_id: 2, email: "seller@folloze.com" };
    this.callCount = 0;
    this.template = templateConfig();
    this.boardConfig = JSON.parse(JSON.stringify(this.template));
    this.publishedConfig = null;
    this.meta = { id: 9001, name: "copy", is_template: false, is_public: false, has_published_version: false, slug: null };
    this.nextId = 1100;
    this.items = [
      "Website Resource Center - Check Point Security",
      "White Paper to Experience - Cisco",
      "Acquisition ABM - Instructure",
      "Field Event Promotion - Bloomreach",
      "Expansion ABM - Aprio",
      "Product Promotion - Lenovo",
    ].map((title, index) => ({ id: 1000 + index, board_id: 9001, title, item_type: "link", item_source: 1, url: `https://example.com/${index}`, image: { url: `https://img/${index}.png` }, categories_ids: [22] }));
    this.failCopiedAuditOnce = false;
    this.configPutCount = 0;
    this.copyCount = 0;
    this.failDirectLinkCreation = false;
    this.boardItemsReadCount = 0;
    this.corruptFinalCover = false;
    this.ignoreCoverRepair = false;
    this.publishCount = 0;
    this.mutateRoiBeforeSave = false;
  }

  async upload(file) {
    this.callCount += 1;
    return { file_name: path.basename(file), url: `https://uploads/${path.basename(file)}`, file_id: `id-${path.basename(file)}`, storage_provider_id: 7, file_meta: { file_size: 10 } };
  }

  async request(route, method = "GET", body) {
    this.callCount += 1;
    if (route === "/prism/248623") return { status: 200, data: { id: 248623, name: TEMPLATE_NAME, is_template: true } };
    if (route === "/api/v1/boards/248623/config") return { status: 200, data: { unpublished_config: JSON.parse(JSON.stringify(this.template)) } };
    if (route === "/api/v1/boards/248623/copy") { this.copyCount += 1; return { status: 200, data: { board_id: 9001 } }; }
    if (route === "/prism/9001" && method === "GET") {
      if (this.failCopiedAuditOnce) { this.failCopiedAuditOnce = false; throw new Error("injected post-copy failure"); }
      return { status: 200, data: { ...this.meta, public_link: this.meta.is_public ? "https://experience.folloze.com/example-resource-center" : null } };
    }
    if (route === "/prism/9001" && method === "PUT") { Object.assign(this.meta, body.board); return { status: 200, data: this.meta }; }
    if (route.endsWith("/slugs/validations")) return { status: 200, data: { valid: true } };
    if (route === "/api/v1/boards/9001/slugs") { this.meta.slug = body.slug; return { status: 200, data: { slug: body.slug } }; }
    if (route === "/api/v1/boards/9001/config" && method === "GET") {
      if (this.mutateRoiBeforeSave && this.configPutCount === 0) {
        this.boardConfig.pages.default.widgets[WIDGETS.roi].data.content = "<h2>tampered ROI</h2>";
      }
      return { status: 200, data: { unpublished_config: JSON.parse(JSON.stringify(this.boardConfig)), published_config: this.publishedConfig && JSON.parse(JSON.stringify(this.publishedConfig)) } };
    }
    if (route === "/api/v1/boards/9001/config" && method === "PUT") { this.configPutCount += 1; this.boardConfig = JSON.parse(JSON.stringify(body.config)); return { status: 200, data: {} }; }
    if (route === "/api/v1/boards/9001/categories") return { status: 200, data: { data: { 11: { id: 11, name: "Essentials" }, 22: { id: 22, name: "Example Boards" } } } };
    if (route === "/api/v1/boards/9001/items" && method === "POST") {
      this.boardItemsReadCount += 1;
      if (this.corruptFinalCover && this.boardItemsReadCount >= 2) {
        const recording = this.items.find((item) => item.title?.includes("Platform Demo"));
        if (recording) recording.image = { url: "https://img.invalid/stale-cover.png" };
      }
      return { status: 200, data: { item_ids: this.items.map((item) => item.id), data: Object.fromEntries(this.items.map((item) => [item.id, item])) } };
    }
    if (route === "/api/v1/items/content_items" && method === "POST") return { status: 201, data: { ...body, id: this.nextId++ } };
    if (route === "/api/v1/items" && method === "POST") {
      if (this.failDirectLinkCreation && body.item_type === "link") throw new Error("injected direct link creation failure");
      const item = { ...body, id: this.nextId++, board_id: 9001, categories_ids: body.categories_ids || [], image: body.image, content_item_id: body.content_item_id || null };
      this.items.push(item); return { status: 201, data: item };
    }
    const copyItemMatch = route.match(/^\/api\/v1\/items\/(\d+)\/copy$/);
    if (copyItemMatch && method === "POST") {
      const seed = this.items.find((item) => item.id === Number(copyItemMatch[1]));
      const copied = { ...seed, id: this.nextId++, board_id: 9001, content_item_id: seed.content_item_id || this.nextId++ };
      this.items.push(copied);
      return { status: 201, data: copied };
    }
    const detachItemMatch = route.match(/^\/api\/v1\/items\/(\d+)\/detach$/);
    if (detachItemMatch && method === "POST") {
      const item = this.items.find((candidate) => candidate.id === Number(detachItemMatch[1]));
      item.content_item_id = this.nextId++;
      return { status: 200, data: item };
    }
    if (/^\/api\/v1\/items\/content_items\/\d+$/.test(route) && method === "PUT") return { status: 200, data: body };
    const itemMatch = route.match(/^\/api\/v1\/items\/(\d+)$/);
    if (itemMatch && method === "GET") return { status: 200, data: this.items.find((item) => item.id === Number(itemMatch[1])) };
    if (itemMatch && method === "PUT") {
      const index = this.items.findIndex((item) => item.id === Number(itemMatch[1]));
      const update = this.ignoreCoverRepair ? { ...body, image: this.items[index].image } : body;
      this.items[index] = { ...this.items[index], ...update };
      return { status: 200, data: this.items[index] };
    }
    const slugMatch = route.match(/^\/api\/v1\/items\/(\d+)\/slugs$/);
    if (slugMatch) {
      const item = this.items.find((candidate) => candidate.id === Number(slugMatch[1])); item.slug = body.slug;
      return { status: 200, data: item };
    }
    if (/\/api\/v1\/categories\/\d+\/category_items/.test(route)) {
      const item = this.items.find((candidate) => candidate.id === body.item_id); if (!item.categories_ids.includes(11)) item.categories_ids.push(11);
      return { status: 200, data: item };
    }
    if (route === "/api/v1/boards/9001/publish") {
      this.publishCount += 1;
      this.meta.has_published_version = true; this.publishedConfig = JSON.parse(JSON.stringify(this.boardConfig));
      return { status: 200, data: { published: true } };
    }
    throw new Error(`Unhandled fake request ${method} ${route}`);
  }
}

function setup(context) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-writer-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  return { root, files: makeFiles(root) };
}

test("dry-run is the default and performs no external calls", async (context) => {
  const { files } = setup(context);
  const client = new FakeClient();
  const receipt = await runWriter(makeSpec(files), { client });
  assert.equal(receipt.mode, "dry_run");
  assert.equal(receipt.external_writes_performed, false);
  assert.equal(client.callCount, 0);
});

test("apply requires exact run confirmation and external-write authorization", async (context) => {
  const { root, files } = setup(context);
  await assert.rejects(() => runWriter(makeSpec(files), { apply: true, confirmRunId: "wrong", allowExternalWrites: true, statePath: path.join(root, "state.json"), client: new FakeClient() }), /confirm-run-id/);
  await assert.rejects(() => runWriter(makeSpec(files), { apply: true, confirmRunId: "writer-test-001", statePath: path.join(root, "state.json"), client: new FakeClient() }), /allow-external-writes/);
});

test("full mocked apply preserves ROI, edits only value text, publishes, and emits resumable evidence", async (context) => {
  const { root, files } = setup(context);
  const client = new FakeClient();
  const receipt = await runWriter(makeSpec(files), {
    apply: true,
    confirmRunId: "writer-test-001",
    allowExternalWrites: true,
    statePath: path.join(root, "state.json"),
    client,
  });
  assert.equal(receipt.ready, true);
  assert.equal(receipt.board.id, 9001);
  assert.equal(receipt.board.is_public, true);
  assert.equal(receipt.publish.performed, true);
  assert.equal(receipt.config.roi_byte_identical_to_template, true);
  assert.equal(receipt.config.value_html_diff_allowlist_passed, true);
  assert.equal(receipt.config.hashes_match, true);
  assert.equal(client.configPutCount, 1);
  assert.equal(receipt.essentials.recording.attachment_mode, "direct_creation");
  assert.equal(receipt.examples.added.length, 1);
  assert.equal(client.boardItemsReadCount, 2, "one inventory load plus one final aggregate readback");
  assert.match(client.boardConfig.pages.default.widgets[WIDGETS.value].data.content, /heading-0-new/);
  assert.match(client.boardConfig.pages.default.widgets[WIDGETS.value].data.content, /protected-0/);
  assert.equal(fs.statSync(path.join(root, "state.json")).mode & 0o777, 0o600);
});

test("an account example sharing a protected baseline URL creates a distinct item", async (context) => {
  const { root, files } = setup(context);
  const client = new FakeClient();
  const spec = makeSpec(files);
  const protectedTitle = client.items[0].title;
  client.items[0].url = spec.examples[0].url;
  const receipt = await runWriter(spec, {
    apply: true,
    confirmRunId: "writer-test-001",
    allowExternalWrites: true,
    statePath: path.join(root, "baseline-overlap-state.json"),
    client,
  });
  const overlappingItems = client.items.filter((item) => item.url === spec.examples[0].url);
  assert.equal(receipt.ready, true);
  assert.equal(receipt.examples.baseline_preserved, true);
  assert.equal(client.items.some((item) => item.title === protectedTitle), true);
  assert.equal(overlappingItems.length, 2);
  assert.notEqual(receipt.examples.added[0].id, client.items[0].id);
});

test("cover persistence failure blocks before public-state mutation", async (context) => {
  const { root, files } = setup(context);
  const client = new FakeClient();
  client.corruptFinalCover = true;
  client.ignoreCoverRepair = true;
  await assert.rejects(
    () =>
      runWriter(makeSpec(files), {
        apply: true,
        confirmRunId: "writer-test-001",
        allowExternalWrites: true,
        statePath: path.join(root, "state.json"),
        client,
        sleep: async () => {},
      }),
    /did not persist before publish/
  );
  assert.equal(client.publishCount, 0);
  assert.equal(client.meta.is_public, false);
});

test("adversarial ROI mutation is rejected before save or publish", async (context) => {
  const { root, files } = setup(context);
  const client = new FakeClient();
  client.mutateRoiBeforeSave = true;
  await assert.rejects(
    () =>
      runWriter(makeSpec(files), {
        apply: true,
        confirmRunId: "writer-test-001",
        allowExternalWrites: true,
        statePath: path.join(root, "state.json"),
        client,
      }),
    /ROI widget marker is missing|ROI changed during config preparation/
  );
  assert.equal(client.configPutCount, 0);
  assert.equal(client.publishCount, 0);
  assert.equal(client.meta.is_public, false);
});

test("no-call build accepts a deck and order form without a recording", async (context) => {
  const { root, files } = setup(context);
  const client = new FakeClient();
  const spec = makeSpec(files);
  spec.assets.recording = null;
  spec.assets.order_form = {
    path: files["order-form.pdf"],
    cover_path: files["order-form.png"],
    title: "Example | Order Form",
    description: "Review the proposed commercial terms.",
  };
  const receipt = await runWriter(spec, {
    apply: true,
    confirmRunId: "writer-test-001",
    allowExternalWrites: true,
    statePath: path.join(root, "state.json"),
    client,
  });
  assert.equal(receipt.ready, true);
  assert.equal(receipt.essentials.recording, undefined);
  assert.equal(receipt.essentials.order_form.item_type, "pdf");
  assert.equal(receipt.essentials.deck.item_type, "pdf");
});

test("example-only update appends to an existing board without copying or changing value and ROI widgets", async (context) => {
  const { root, files } = setup(context);
  const client = new FakeClient();
  client.meta.name = "Example | Folloze Resource Center";
  client.meta.slug = "example-resource-center";
  const beforeValue = client.boardConfig.pages.default.widgets[WIDGETS.value].data.content;
  const beforeRoi = client.boardConfig.pages.default.widgets[WIDGETS.roi].data.content;
  const spec = makeSpec(files, { operation: "append_examples" });
  spec.run_id = "writer-append-001";
  spec.board.existing_id = 9001;
  const receipt = await runWriter(spec, {
    apply: true,
    confirmRunId: "writer-append-001",
    allowExternalWrites: true,
    statePath: path.join(root, "append-state.json"),
    client,
  });
  assert.equal(receipt.ready, true);
  assert.equal(receipt.operation, "append_examples");
  assert.equal(receipt.board.id, 9001);
  assert.equal(receipt.examples.added.length, 1);
  assert.equal(receipt.config.value_html_diff_allowlist_passed, true);
  assert.equal(client.copyCount, 0);
  assert.equal(client.boardConfig.pages.default.widgets[WIDGETS.value].data.content, beforeValue);
  assert.equal(client.boardConfig.pages.default.widgets[WIDGETS.roi].data.content, beforeRoi);
});

test("example-only update falls back to a detached native link seed", async (context) => {
  const { root, files } = setup(context);
  const client = new FakeClient();
  client.meta.name = "Example | Folloze Resource Center";
  client.meta.slug = "example-resource-center";
  client.items.forEach((item, index) => { item.content_item_id = 5000 + index; });
  client.failDirectLinkCreation = true;
  const spec = makeSpec(files, { operation: "append_examples" });
  spec.run_id = "writer-append-fallback-001";
  spec.board.existing_id = 9001;
  const receipt = await runWriter(spec, {
    apply: true,
    confirmRunId: "writer-append-fallback-001",
    allowExternalWrites: true,
    statePath: path.join(root, "append-fallback-state.json"),
    client,
  });
  assert.equal(receipt.ready, true);
  assert.equal(receipt.examples.added[0].attachment_mode, "automatic_native_seed_fallback");
  assert.ok(receipt.examples.added[0].content_item_id);
});

test("template copy is checkpointed before a later failure and is reused on resume", async (context) => {
  const { root, files } = setup(context);
  const statePath = path.join(root, "state.json");
  const client = new FakeClient();
  client.failCopiedAuditOnce = true;
  const options = { apply: true, confirmRunId: "writer-test-001", allowExternalWrites: true, statePath, client };
  await assert.rejects(() => runWriter(makeSpec(files), options), /post-copy failure/);
  const saved = JSON.parse(fs.readFileSync(statePath, "utf8"));
  assert.equal(saved.operations.template_copy.receipt.board_id, 9001);
  const receipt = await runWriter(makeSpec(files), options);
  assert.equal(receipt.board.id, 9001);
  assert.equal(receipt.ready, true);
});

test("capabilities command is credential-free and machine delimited", () => {
  const completed = spawnSync(process.execPath, [path.join(__dirname, "fast_path_writer.js"), "--capabilities"], { encoding: "utf8" });
  assert.equal(completed.status, 0);
  assert.match(completed.stdout, /"dry_run_default":true/);
  assert.match(completed.stdout, /^DSR_WRITER_CAPABILITIES_JSON_BEGIN\n/);
  assert.match(completed.stdout, /\nDSR_WRITER_CAPABILITIES_JSON_END\n$/);
  assert.doesNotMatch(completed.stdout, /access_token|refresh_token|Bearer/);
});

test("documented positional plan and apply commands map to safe writer modes", () => {
  assert.deepEqual(parseArgs(["plan", "--spec", "write.json"]), {
    command: "run",
    apply: false,
    allowExternalWrites: false,
    specPath: "write.json",
  });
  assert.deepEqual(
    parseArgs(["apply", "--spec", "write.json", "--confirm-run-id", "run-001", "--state", "state.json", "--allow-external-writes"]),
    {
      command: "run",
      apply: true,
      allowExternalWrites: true,
      specPath: "write.json",
      confirmRunId: "run-001",
      statePath: "state.json",
    }
  );
});

test("receipt carries the orchestrator hash separately from the write-spec hash", async (context) => {
  const { files } = setup(context);
  const receipt = await runWriter(makeSpec(files), { orchestratorSpecSha256: "orchestrator-hash" });
  assert.equal(receipt.spec_sha256, "orchestrator-hash");
  assert.match(receipt.write_spec_sha256, /^[a-f0-9]{64}$/);
});

test("copy response parsing accepts only documented board-id shapes", () => {
  assert.equal(findBoardId({ board_id: 9001 }, 248623), 9001);
  assert.equal(findBoardId({ data: { board: { id: 9002 } } }, 248623), 9002);
  assert.equal(findBoardId({ unrelated: { data: { id: 9999 } } }, 248623), null);
  assert.equal(findBoardId({ id: 9999 }, 248623), 9999);
  assert.equal(findBoardId({ id: 248623 }, 248623), null);
});

test("template copy uses fast adaptive polling instead of fixed two-second sleeps", async () => {
  const sleeps = [];
  let call = 0;
  const client = {
    async request() {
      call += 1;
      if (call < 3) return { status: 206, data: { guid: "copy-guid" } };
      return { status: 200, data: { board_id: 9001 } };
    },
  };
  const receipt = await copyTemplate(client, 248623, async (milliseconds) => sleeps.push(milliseconds));
  assert.equal(receipt.board_id, 9001);
  assert.equal(receipt.attempts, 3);
  assert.deepEqual(sleeps, [250, 500]);
});

test("template copy fails within the bounded production wait budget", async () => {
  const sleeps = [];
  const client = { async request() { return { status: 206, data: { guid: "copy-guid" } }; } };
  await assert.rejects(
    () => copyTemplate(client, 248623, async (milliseconds) => sleeps.push(milliseconds), { budgetMs: 1_000 }),
    /inside its 1000ms production budget/
  );
  assert.deepEqual(sleeps, [250, 500]);
});

test("closed spec rejects credentials and unsupported card-four AI language", async (context) => {
  const { files } = setup(context);
  const withSecret = makeSpec(files);
  withSecret.target.access_token = "bad";
  await assert.rejects(() => runWriter(withSecret), /credentials must come from the selected auth profile/);
  const withAi = makeSpec(files);
  withAi.copy.value_section.cards[3].body.to = "Connect Claude into the workflow.";
  await assert.rejects(() => runWriter(withAi), /without an affirmative AI signal/);
});

test("Folloze client emits compact per-call timing evidence", async () => {
  const payload = Buffer.from(JSON.stringify({ iss: "https://app.folloze.com", sub: "42", org_id: 2 })).toString("base64url");
  const token = `header.${payload}.signature`;
  const client = new FollozeClient({
    baseUrl: "https://app.folloze.com",
    profile: "engage",
    environment: { FOLLOZE_ACCESS_TOKEN: token },
    fetchImpl: async () => ({ ok: true, status: 200, async text() { return '{"ok":true}'; } }),
  });
  await client.request("/api/v1/health");
  const performance = client.performanceSummary();
  assert.equal(performance.api_calls, 1);
  assert.equal(performance.observed_call_count, 1);
  assert.equal(performance.slowest_calls[0].path, "/api/v1/health");
  assert.equal(performance.slowest_calls[0].status, 200);
  assert.doesNotMatch(JSON.stringify(performance), /header\.|signature|Bearer/);
});
