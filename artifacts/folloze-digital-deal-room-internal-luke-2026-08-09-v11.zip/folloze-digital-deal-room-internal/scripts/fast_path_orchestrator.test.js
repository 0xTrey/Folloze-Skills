"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { spawnSync } = require("node:child_process");

const { runOrchestrator, validateSpec } = require("./fast_path_orchestrator.js");

function receiptCommand(begin, end, overrides = {}) {
  const extra = JSON.stringify(overrides);
  return [
    process.execPath,
    "-e",
    `const value={run_id:process.env.DSR_RUN_ID,spec_sha256:process.env.DSR_SPEC_SHA256,ready:true,...${extra}};console.log(${JSON.stringify(begin)}+'\\n'+JSON.stringify(value)+'\\n'+${JSON.stringify(end)})`,
  ];
}

function preflightCommand(overrides = {}) {
  const extra = JSON.stringify(overrides);
  return [
    process.execPath,
    "-e",
    `const value={ready:true,folloze_writes_performed:0,external_writes_performed:0,...${extra}};console.log('DSR_PREFLIGHT_JSON_BEGIN\\n'+JSON.stringify(value)+'\\nDSR_PREFLIGHT_JSON_END')`,
  ];
}

function spec(command, overrides = {}) {
  return validateSpec({
    run_id: "test-run-001",
    account: "Example Co",
    usage_tracking: { token_source: "codex_goal_receipt", cost_source: "model_pricing_receipt" },
    stages: [
      {
        id: "preflight",
        role: "preflight",
        command,
        timeout_seconds: 5,
        write_capability: "read_only",
        parallel_group: "intake",
        required_output_marker: "DSR_PREFLIGHT_JSON_END",
        ...overrides,
      },
      {
        id: "assets",
        command: [process.execPath, "-e", "process.exit(0)"],
        timeout_seconds: 5,
        write_capability: "read_only",
        parallel_group: "intake",
      },
      {
        id: "write_board",
        role: "production_writer",
        command: receiptCommand("DSR_WRITER_JSON_BEGIN", "DSR_WRITER_JSON_END"),
        timeout_seconds: 5,
        write_capability: "external_write",
        depends_on: ["preflight", "assets"],
        required_output_marker: "DSR_WRITER_JSON_END",
      },
      {
        id: "final_verify",
        role: "final_verifier",
        command: receiptCommand("DSR_VERIFY_JSON_BEGIN", "DSR_VERIFY_JSON_END"),
        timeout_seconds: 5,
        write_capability: "read_only",
        depends_on: ["preflight", "assets", "write_board"],
        required_output_marker: "DSR_VERIFY_JSON_END",
      },
    ],
  });
}

test("dry-run validates but does not execute adapters", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const sentinel = path.join(root, "must-not-exist");
  const runSpec = spec([process.execPath, "-e", `require('fs').writeFileSync(${JSON.stringify(sentinel)}, 'bad')`]);
  const receipt = await runOrchestrator(runSpec);
  assert.equal(receipt.ready, true);
  assert.equal(receipt.mode, "dry_run");
  assert(receipt.stages.every((stage) => stage.status === "planned_not_executed"));
  assert.equal(receipt.usage_measurement.tokens_available, true);
  assert.equal(fs.existsSync(sentinel), false);
});

test("apply state makes a successful stage idempotently resumable", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const statePath = path.join(root, "state.json");
  const runSpec = spec(preflightCommand());
  const options = { apply: true, confirmRunId: runSpec.run_id, statePath, allowExternalWrites: true };
  const first = await runOrchestrator(runSpec, options);
  const second = await runOrchestrator(runSpec, options);
  assert.equal(first.ready, true);
  assert.equal(first.stages[0].status, "passed");
  assert.equal(first.parallel_batches[0].ran_concurrently, true);
  assert.equal(second.ready, true);
  assert.equal(second.stages.find((stage) => stage.id === "preflight").status, "passed");
  assert.equal(second.stages.find((stage) => stage.id === "assets").status, "resumed_completed");
  assert.equal(second.stages.find((stage) => stage.id === "write_board").status, "resumed_completed");
  assert.equal(second.stages.find((stage) => stage.id === "final_verify").status, "passed");
});

test("all independent ready read stages run concurrently across parallel groups", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const delayed = [process.execPath, "-e", "setTimeout(() => process.exit(0), 120)"];
  const runSpec = validateSpec({
    run_id: "parallel-ready-001",
    account: "Example Co",
    usage_tracking: { token_source: "test", cost_source: "test" },
    stages: [
      {
        id: "preflight",
        role: "preflight",
        command: preflightCommand(),
        timeout_seconds: 5,
        write_capability: "read_only",
        parallel_group: "intake",
        required_output_marker: "DSR_PREFLIGHT_JSON_END",
      },
      { id: "assets", command: delayed, timeout_seconds: 5, write_capability: "read_only", parallel_group: "intake" },
      { id: "research", command: delayed, timeout_seconds: 5, write_capability: "read_only", parallel_group: "evidence" },
      { id: "tiles", command: delayed, timeout_seconds: 5, write_capability: "read_only", parallel_group: "evidence" },
      {
        id: "write_board",
        role: "production_writer",
        command: receiptCommand("DSR_WRITER_JSON_BEGIN", "DSR_WRITER_JSON_END"),
        timeout_seconds: 5,
        write_capability: "external_write",
        depends_on: ["preflight", "assets", "research", "tiles"],
        required_output_marker: "DSR_WRITER_JSON_END",
      },
      {
        id: "final_verify",
        role: "final_verifier",
        command: receiptCommand("DSR_VERIFY_JSON_BEGIN", "DSR_VERIFY_JSON_END"),
        timeout_seconds: 5,
        write_capability: "read_only",
        depends_on: ["preflight", "assets", "research", "tiles", "write_board"],
        required_output_marker: "DSR_VERIFY_JSON_END",
      },
    ],
  });
  const receipt = await runOrchestrator(runSpec, {
    apply: true,
    confirmRunId: runSpec.run_id,
    statePath: path.join(root, "state.json"),
    allowExternalWrites: true,
  });
  assert.equal(receipt.ready, true);
  assert.deepEqual(receipt.parallel_batches[0].stage_ids, ["preflight", "assets", "research", "tiles"]);
  assert.equal(receipt.parallel_batches[0].group, "mixed_ready");
  assert.equal(receipt.parallel_batches[0].ran_concurrently, true);
  assert(receipt.parallel_batches[0].elapsed_ms < 350);
});

test("retryable adapters receive no more than one retry", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const runSpec = spec([process.execPath, "-e", "process.exit(75)"], { retryable: true });
  const receipt = await runOrchestrator(runSpec, {
    apply: true,
    confirmRunId: runSpec.run_id,
    statePath: path.join(root, "state.json"),
    allowExternalWrites: true,
  });
  assert.equal(receipt.ready, false);
  assert.equal(receipt.stages[0].attempts, 2);
  assert.equal(receipt.stages[0].retry_used, true);
});

test("non-transient adapter failures are not retried", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const runSpec = spec([process.execPath, "-e", "process.exit(9)"], { retryable: true });
  const receipt = await runOrchestrator(runSpec, {
    apply: true,
    confirmRunId: runSpec.run_id,
    statePath: path.join(root, "state.json"),
    allowExternalWrites: true,
  });
  assert.equal(receipt.ready, false);
  assert.equal(receipt.stages[0].attempts, 1);
  assert.equal(receipt.stages[0].retry_used, false);
});

test("production writer receipt must match the orchestrated run", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const runSpec = spec(preflightCommand());
  runSpec.stages.find((stage) => stage.role === "production_writer").command = receiptCommand(
    "DSR_WRITER_JSON_BEGIN",
    "DSR_WRITER_JSON_END",
    { run_id: "wrong-run" }
  );
  const receipt = await runOrchestrator(runSpec, {
    apply: true,
    confirmRunId: runSpec.run_id,
    statePath: path.join(root, "state.json"),
    allowExternalWrites: true,
  });
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "adapter_receipt_mismatch"));
});

test("exit-zero malformed writer marker cannot forge completion", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const runSpec = spec(preflightCommand());
  runSpec.stages.find((stage) => stage.role === "production_writer").command = [
    process.execPath,
    "-e",
    "console.log('DSR_WRITER_JSON_BEGIN\\n{not-json}\\nDSR_WRITER_JSON_END')",
  ];
  const receipt = await runOrchestrator(runSpec, {
    apply: true,
    confirmRunId: runSpec.run_id,
    statePath: path.join(root, "state.json"),
    allowExternalWrites: true,
  });
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "adapter_receipt_invalid"));
});

test("endpoint drift gets one targeted retry then returns maintenance_required", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const runSpec = spec(preflightCommand());
  const writer = runSpec.stages.find((stage) => stage.role === "production_writer");
  writer.retryable = true;
  writer.command = receiptCommand("DSR_WRITER_JSON_BEGIN", "DSR_WRITER_JSON_END", {
    ready: false,
    transient: true,
    maintenance_required: true,
  });
  const receipt = await runOrchestrator(runSpec, {
    apply: true,
    confirmRunId: runSpec.run_id,
    statePath: path.join(root, "state.json"),
    allowExternalWrites: true,
  });
  const writerResult = receipt.stages.find((stage) => stage.id === "write_board");
  assert.equal(writerResult.attempts, 2);
  assert.equal(receipt.terminal_state, "maintenance_required");
  assert(receipt.blockers.some((blocker) => blocker.code === "maintenance_required"));
});

test("scaled hard ceiling emits a truthful timeout and starts no retry after escalation", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const runSpec = spec([process.execPath, "-e", "setTimeout(() => process.exit(0), 1000)"], { retryable: true });
  const receipt = await runOrchestrator(
    runSpec,
    {
      apply: true,
      confirmRunId: runSpec.run_id,
      statePath: path.join(root, "state.json"),
      allowExternalWrites: true,
    },
    { deadlines: { target_seconds: 0.01, escalation_seconds: 0.02, hard_cap_seconds: 0.05 } }
  );
  const preflight = receipt.stages.find((stage) => stage.id === "preflight");
  assert.equal(receipt.ready, false);
  assert.equal(preflight.attempts, 1);
  assert.equal(preflight.attempt_results[0].failure_code, "adapter_timeout");
  assert(receipt.elapsed_ms < 500);
  assert.equal(receipt.deadline_status, "hard_cap_exceeded");
});

test("external writes cannot be independent of preflight", () => {
  assert.throws(
    () =>
      validateSpec({
        run_id: "unsafe-run",
        account: "Example Co",
        stages: [
          {
            id: "preflight",
            role: "preflight",
            command: [process.execPath, "-e", ""],
            timeout_seconds: 5,
            parallel_group: "intake",
            required_output_marker: "DSR_PREFLIGHT_JSON_END",
          },
          {
            id: "assets",
            command: [process.execPath, "-e", ""],
            timeout_seconds: 5,
            parallel_group: "intake",
          },
          {
            id: "writer",
            role: "production_writer",
            command: [process.execPath, "-e", ""],
            timeout_seconds: 5,
            write_capability: "external_write",
            depends_on: ["assets"],
            required_output_marker: "DSR_WRITER_JSON_END",
          },
          {
            id: "verify",
            role: "final_verifier",
            command: [process.execPath, "-e", ""],
            timeout_seconds: 5,
            depends_on: ["preflight", "assets", "writer"],
            required_output_marker: "DSR_VERIFY_JSON_END",
          },
        ],
      }),
    (error) => error.code === "external_write_preflight_dependency"
  );
});

test("CLI receipt is atomically replaced on resume", (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const specPath = path.join(root, "run.json");
  const statePath = path.join(root, "state.json");
  const receiptPath = path.join(root, "receipt.json");
  const runSpec = spec(preflightCommand());
  fs.writeFileSync(specPath, `${JSON.stringify(runSpec)}\n`);
  const argv = [
    require.resolve("./fast_path_orchestrator.js"),
    "--spec",
    specPath,
    "--apply",
    "--confirm-run-id",
    runSpec.run_id,
    "--state",
    statePath,
    "--allow-external-writes",
    "--receipt",
    receiptPath,
  ];
  const first = spawnSync(process.execPath, argv, { encoding: "utf8", timeout: 10_000 });
  const second = spawnSync(process.execPath, argv, { encoding: "utf8", timeout: 10_000 });
  assert.equal(first.status, 0, first.stdout || first.stderr);
  assert.equal(second.status, 0, second.stdout || second.stderr);
  assert.equal(JSON.parse(fs.readFileSync(receiptPath, "utf8")).ready, true);
});

test("blocked preflight receipt performs zero production writes", async (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-orchestrator-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const sentinel = path.join(root, "writer-must-not-run");
  const runSpec = spec(preflightCommand({ ready: false }));
  runSpec.stages.find((stage) => stage.role === "production_writer").command = [
    process.execPath,
    "-e",
    `require('fs').writeFileSync(${JSON.stringify(sentinel)}, 'unsafe')`,
  ];
  const receipt = await runOrchestrator(runSpec, {
    apply: true,
    confirmRunId: runSpec.run_id,
    statePath: path.join(root, "state.json"),
    allowExternalWrites: true,
  });
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "preflight_receipt_blocked"));
  assert.equal(receipt.external_write_stages_executed, 0);
  assert.equal(fs.existsSync(sentinel), false);
});
