"use strict";

const assert = require("node:assert/strict");
const test = require("node:test");

const { evaluateReceipts } = require("./benchmark_fast_path.js");

function entry(index, elapsedSeconds, overrides = {}) {
  const receipt = {
    mode: "apply",
    runtime_profile: "fast_ready",
    terminal_state: "completed",
    ready: true,
    elapsed_ms: elapsedSeconds * 1000,
    benchmark_evidence: {
      environment: "production",
      warmed: true,
      external_waits_included: true,
      window_id: "benchmark-2026-08-08",
      attempt_index: index,
    },
    ...overrides,
  };
  return { source: `run-${index}.json`, raw: JSON.stringify(receipt), receipt };
}

test("five complete warmed production attempts demonstrate the SLA", () => {
  const report = evaluateReceipts([entry(1, 180), entry(2, 220), entry(3, 250), entry(4, 290), entry(5, 430)]);
  assert.equal(report.passed, true);
  assert.equal(report.observed.p50_seconds, 250);
  assert.equal(report.observed.p95_seconds, 430);
});

test("failed attempts remain in the complete benchmark window", () => {
  const report = evaluateReceipts([
    entry(1, 180),
    entry(2, 220),
    entry(3, 260, { ready: false, terminal_state: "nonterminal_blocked" }),
    entry(4, 300),
    entry(5, 470),
  ]);
  assert.equal(report.passed, true);
  assert.equal(report.includes_non_successful_runs, true);
});

test("incomplete, synthetic, or slow samples cannot support the production claim", () => {
  const report = evaluateReceipts([
    entry(1, 100),
    entry(2, 120),
    entry(4, 130),
    entry(5, 140, { runtime_profile: "standard_ready" }),
  ]);
  assert.equal(report.passed, false);
  assert(report.failures.some((failure) => failure.code === "insufficient_runs"));
  assert(report.failures.some((failure) => failure.code === "attempt_sequence_incomplete"));
  assert(report.failures.some((failure) => failure.code === "run_ineligible"));
});
