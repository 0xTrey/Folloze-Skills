#!/usr/bin/env node
"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const MIN_RUNS = 5;
const TARGETS = Object.freeze({ p50_seconds: 300, p95_seconds: 480, hard_cap_seconds: 600 });

function percentile(values, percent) {
  const ordered = [...values].sort((left, right) => left - right);
  return ordered[Math.max(0, Math.ceil((percent / 100) * ordered.length) - 1)];
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function evaluateReceipts(entries) {
  const failures = [];
  if (entries.length < MIN_RUNS) failures.push({ code: "insufficient_runs", required: MIN_RUNS, actual: entries.length });
  const windowIds = new Set();
  const attemptIndexes = [];
  const elapsedSeconds = [];
  const runs = entries.map(({ source, raw, receipt }) => {
    const evidence = receipt.benchmark_evidence || {};
    windowIds.add(evidence.window_id);
    attemptIndexes.push(evidence.attempt_index);
    const elapsed = Number(receipt.elapsed_ms) / 1000;
    elapsedSeconds.push(elapsed);
    const terminal =
      typeof receipt.terminal_state === "string" &&
      !new Set(["running", "dry_run_validated", "dry_run_blocked"]).has(receipt.terminal_state);
    const eligible =
      receipt.mode === "apply" &&
      receipt.runtime_profile === "fast_ready" &&
      evidence.environment === "production" &&
      evidence.warmed === true &&
      evidence.external_waits_included === true &&
      Number.isInteger(evidence.attempt_index) &&
      Number.isFinite(elapsed) &&
      elapsed >= 0 &&
      terminal;
    if (!eligible) failures.push({ code: "run_ineligible", source });
    return {
      source,
      receipt_sha256: sha256(raw),
      attempt_index: evidence.attempt_index ?? null,
      elapsed_seconds: Number.isFinite(elapsed) ? Math.round(elapsed * 1000) / 1000 : null,
      terminal_state: receipt.terminal_state || null,
      ready: receipt.ready === true,
      eligible,
    };
  });
  if (windowIds.size !== 1 || windowIds.has(undefined)) failures.push({ code: "benchmark_window_invalid" });
  const expectedIndexes = Array.from({ length: entries.length }, (_, index) => index + 1);
  if (JSON.stringify([...attemptIndexes].sort((a, b) => a - b)) !== JSON.stringify(expectedIndexes)) {
    failures.push({ code: "attempt_sequence_incomplete" });
  }
  const safeTimes = elapsedSeconds.filter(Number.isFinite);
  const p50 = safeTimes.length ? percentile(safeTimes, 50) : null;
  const p95 = safeTimes.length ? percentile(safeTimes, 95) : null;
  const maximum = safeTimes.length ? Math.max(...safeTimes) : null;
  if (p50 === null || p50 > TARGETS.p50_seconds) failures.push({ code: "p50_target_missed", actual_seconds: p50 });
  if (p95 === null || p95 > TARGETS.p95_seconds) failures.push({ code: "p95_target_missed", actual_seconds: p95 });
  if (maximum === null || maximum > TARGETS.hard_cap_seconds) failures.push({ code: "hard_cap_missed", actual_seconds: maximum });
  return {
    schema_version: "1.0",
    passed: failures.length === 0,
    claim: failures.length === 0 ? "production_sla_demonstrated" : "production_sla_not_demonstrated",
    sample_count: entries.length,
    includes_non_successful_runs: runs.some((run) => !run.ready),
    targets: TARGETS,
    observed: { p50_seconds: p50, p95_seconds: p95, max_seconds: maximum },
    failures,
    runs,
  };
}

function parseArgs(argv) {
  const options = { receipts: [] };
  for (let index = 0; index < argv.length; index += 1) {
    const name = argv[index];
    if (name === "--receipt" || name === "--output") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error(`${name} requires a path`);
      index += 1;
      if (name === "--receipt") options.receipts.push(value);
      else options.output = value;
    } else if (name === "--help") options.help = true;
    else throw new Error(`Unknown option: ${name}`);
  }
  return options;
}

function main(argv = process.argv.slice(2)) {
  const options = parseArgs(argv);
  if (options.help) {
    process.stdout.write("Usage: benchmark_fast_path.js --receipt RUN1.json ... --receipt RUN5.json [--output REPORT.json]\n");
    return 0;
  }
  const entries = options.receipts.map((file) => {
    const source = path.resolve(file);
    const raw = fs.readFileSync(source, "utf8");
    return { source, raw, receipt: JSON.parse(raw) };
  });
  const report = evaluateReceipts(entries);
  if (options.output) fs.writeFileSync(path.resolve(options.output), `${JSON.stringify(report)}\n`, { flag: "wx" });
  process.stdout.write(`DSR_BENCHMARK_JSON_BEGIN\n${JSON.stringify(report)}\nDSR_BENCHMARK_JSON_END\n`);
  return report.passed ? 0 : 2;
}

if (require.main === module) process.exitCode = main();

module.exports = { MIN_RUNS, TARGETS, evaluateReceipts, percentile };
