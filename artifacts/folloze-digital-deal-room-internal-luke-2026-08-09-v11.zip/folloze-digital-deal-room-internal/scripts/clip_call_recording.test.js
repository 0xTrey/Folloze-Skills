"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { spawnSync } = require("node:child_process");

function writeTinyWav(destination, seconds = 2) {
  const sampleRate = 8_000;
  const samples = sampleRate * seconds;
  const dataSize = samples * 2;
  const buffer = Buffer.alloc(44 + dataSize);
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write("WAVE", 8);
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(1, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write("data", 36);
  buffer.writeUInt32LE(dataSize, 40);
  fs.writeFileSync(destination, buffer);
}

test("positive opening cut emits verified duration, streams, hashes, and timing evidence", (context) => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-positive-cut-"));
  context.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const source = path.join(root, "source.wav");
  const output = path.join(root, "edited.mp3");
  const transcript = path.join(root, "transcript.txt");
  writeTinyWav(source);
  fs.writeFileSync(transcript, "00:00 Small talk\n00:00.500 Buyer discussion begins\n");
  const completed = spawnSync(
    "python3",
    [
      path.join(__dirname, "clip_call_recording.py"),
      "--input", source,
      "--output", output,
      "--transcript", transcript,
      "--start", "0.5",
      "--end", "1.5",
      "--transcript-source-mode", "local_file",
      "--acquisition-mode", "local_provided",
      "--mode", "software",
    ],
    { encoding: "utf8", timeout: 15_000 }
  );
  assert.equal(completed.status, 0, completed.stderr || completed.stdout);
  const receipt = JSON.parse(completed.stdout);
  assert.equal(receipt.recording_clipped, true);
  assert.equal(receipt.opening_chatter_clipped, true);
  assert.equal(receipt.removed_opening_seconds, 0.5);
  assert.equal(receipt.streams_verified, true);
  assert.equal(receipt.duration_verified, true);
  assert.equal(receipt.source_and_output_hashes_differ, true);
  assert.equal(receipt.technical_edit_verification, "passed");
  assert.equal(receipt.encoder_selected, "libmp3lame");
  assert(Number.isFinite(receipt.processing_elapsed_seconds));
  assert(fs.statSync(output).size > 0);
});
