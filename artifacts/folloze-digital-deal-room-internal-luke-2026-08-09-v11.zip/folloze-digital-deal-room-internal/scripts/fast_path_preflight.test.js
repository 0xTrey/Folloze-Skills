"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const test = require("node:test");
const { spawnSync } = require("node:child_process");

const { runPreflight } = require("./fast_path_preflight.js");

function writeTinyWav(destination) {
  const sampleRate = 8_000;
  const samples = sampleRate;
  const dataSize = samples * 2;
  const buffer = Buffer.alloc(44 + dataSize);
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write("WAVE", 8);
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16);
  buffer.writeUInt16LE(1, 20);
  buffer.writeUInt16LE(1, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(sampleRate * 2, 28);
  buffer.writeUInt16LE(2, 32);
  buffer.writeUInt16LE(16, 34);
  buffer.write("data", 36);
  buffer.writeUInt32LE(dataSize, 40);
  fs.writeFileSync(destination, buffer);
}

function fixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "dsr-fast-preflight-"));
  const handoff = path.join(root, "handoff");
  fs.mkdirSync(handoff);
  fs.writeFileSync(path.join(handoff, "transcript.txt"), "00:00 Customer-ready transcript\n");
  writeTinyWav(path.join(handoff, "meeting.wav"));
  const deck = path.join(root, "presentation.pdf");
  fs.writeFileSync(deck, "%PDF-1.4\n% test-only fixture\n");
  const writer = path.join(root, "writer.js");
  fs.writeFileSync(
    writer,
    `console.log('DSR_WRITER_CAPABILITIES_JSON_BEGIN\\n'+JSON.stringify({ready:true,capabilities:${JSON.stringify([
      "copy_template",
      "upload_assets",
      "save_config",
      "publish",
      "vanity",
      "idempotent_resume",
      "template_248623_guards",
      "receipt",
    ])}})+'\\nDSR_WRITER_CAPABILITIES_JSON_END');\n`
  );
  const editorManifest = path.join(root, "editor.json");
  fs.writeFileSync(
    editorManifest,
    `${JSON.stringify({
      stable_identity: "org-user-123",
      display_name: "Luke Rafferty",
      normalized_email: "luke@folloze.com",
      transport_verified: true,
      session_authenticated: true,
    })}\n`
  );
  const initialized = spawnSync("git", ["init", "-q", root]);
  assert.equal(initialized.status, 0);
  return { root, handoff, deck, writer, editorManifest };
}

test("complete Trey handoff passes without creating files or exposing token", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const before = fs.readdirSync(data.root, { recursive: true }).sort();
  const secret = "test-token-that-must-not-appear";
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: secret, FOLLOZE_MCP_PROFILE: "engage" } }
  );
  const after = fs.readdirSync(data.root, { recursive: true }).sort();
  assert.equal(receipt.ready, true);
  assert.equal(receipt.terminal_state, "preflight_ready");
  assert.equal(receipt.media.probe, "passed");
  assert.equal(receipt.folloze_writes_performed, 0);
  assert.equal(receipt.external_writes_performed, 0);
  assert.deepEqual(after, before);
  assert.equal(JSON.stringify(receipt).includes(secret), false);
});

test("ZIP handoff probes the exact recording entry asynchronously", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const archive = path.join(data.root, "handoff.zip");
  const zipped = spawnSync("zip", ["-q", archive, "transcript.txt", "meeting.wav"], { cwd: data.handoff });
  assert.equal(zipped.status, 0);
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: archive,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, true);
  assert.equal(receipt.inputs.package_kind, "zip");
  assert.equal(receipt.media.source, "bounded_temporary_zip_entry");
  assert.equal(receipt.media.temporary_media_cleaned, true);
});

test("Luke handoff blocks unless editor transport is preflighted", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "luke",
      opportunityOwner: "luke",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "editor_transport_unverified"));
});

test("Trey-operated Luke-owned opportunity still requires Luke editor transport", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "luke",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert.equal(receipt.opportunity_owner, "luke");
  assert.equal(receipt.auth.editor.required, true);
  assert(receipt.blockers.some((blocker) => blocker.code === "editor_transport_unverified"));
});

test("Trey-operated Luke-owned opportunity passes with verified Luke editor transport", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "luke",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      editorManifest: data.editorManifest,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, true);
  assert.equal(receipt.operator, "trey");
  assert.equal(receipt.opportunity_owner, "luke");
  assert.equal(receipt.auth.editor.required, true);
  assert.equal(receipt.auth.editor.stable_identity, "org-user-123");
});

test("missing Opportunity owner blocks before production", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "opportunity_owner_missing"));
  assert.equal(receipt.external_writes_performed, 0);
});

test("Engage production deployment URLs pass examples preflight", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const examplesManifest = path.join(data.root, "examples.json");
  fs.writeFileSync(
    examplesManifest,
    `${JSON.stringify({
      tracker_verified: true,
      tile_library_verified: true,
      examples: [{
        board_id: 247735,
        deployment_url: "https://engage.folloze.com/b65073",
        tile_file_id: "drive-file-123",
      }],
    })}\n`
  );
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      examplesManifest,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, true);
  assert.equal(receipt.examples.examples[0].deployment_url, "https://engage.folloze.com/b65073");
});

test("authenticated designer URLs do not pass examples preflight", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const examplesManifest = path.join(data.root, "examples.json");
  fs.writeFileSync(
    examplesManifest,
    `${JSON.stringify({
      tracker_verified: true,
      tile_library_verified: true,
      examples: [{
        board_id: 247735,
        deployment_url: "https://app.folloze.com/app/board/247735/designer",
        tile_file_id: "drive-file-123",
      }],
    })}\n`
  );
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      examplesManifest,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "example_url_invalid"));
});

test("Luke editor resolution accepts a verified account alias by stable identity", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  fs.writeFileSync(
    data.editorManifest,
    `${JSON.stringify({
      stable_identity: "org-user-123",
      display_name: "Luke Rafferty",
      lookup_email: "luke@folloze.com",
      normalized_email: "luke.rafferty@folloze.com",
      transport_verified: true,
      session_authenticated: true,
    })}\n`
  );
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "luke",
      opportunityOwner: "luke",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      editorManifest: data.editorManifest,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, true);
  assert.equal(receipt.auth.editor.stable_identity, "org-user-123");
  assert.equal(receipt.auth.editor.lookup_email, "luke@folloze.com");
  assert.equal(receipt.auth.editor.normalized_email, "luke.rafferty@folloze.com");
});

test("keyed Folloze template readback is accepted after auth warmup", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "luke",
      opportunityOwner: "luke",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      networkReadback: true,
      editorManifest: data.editorManifest,
      budgetSeconds: 30,
    },
    {
      env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token", FOLLOZE_MCP_PROFILE: "engage" },
      fetch: async () => ({
        ok: true,
        json: async () => ({
          "248623": {
            id: 248623,
            name: "Folloze Resource Center / Digital Deal Room Template - July 2026 Folloze Resource Center",
            is_template: true,
          },
        }),
      }),
    }
  );
  assert.equal(receipt.ready, true);
  assert.equal(receipt.runtime_profile, "fast_ready");
  assert.equal(receipt.auth.template.remote_readback.verified, true);
  assert.equal(receipt.auth.template.remote_readback.template_id, 248623);
});

test("ambiguous transcripts fail closed", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(data.handoff, "second-transcript.srt"), "1\n00:00:00,000 --> 00:00:01,000\nHi\n");
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "transcript_ambiguous"));
});

test("corrupt local recording blocks before any external write", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  fs.writeFileSync(path.join(data.handoff, "meeting.wav"), "not-a-media-file");
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "recording_unreadable"));
  assert.equal(receipt.external_writes_performed, 0);
});

test("missing required deck blocks during preflight", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  fs.unlinkSync(data.deck);
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "deck_missing"));
  assert.equal(receipt.external_writes_performed, 0);
});

test("legacy editor-ready remains usable but cannot classify fast_ready", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "luke",
      opportunityOwner: "luke",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: data.writer,
      outputRepo: data.root,
      networkReadback: true,
      editorReady: true,
      budgetSeconds: 30,
    },
    {
      env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token", FOLLOZE_MCP_PROFILE: "engage" },
      fetch: async () => ({
        ok: true,
        json: async () => ({ id: 248623, name: "Template", is_template: true }),
      }),
    }
  );
  assert.equal(receipt.ready, true);
  assert.equal(receipt.runtime_profile, "standard_ready");
  assert.equal(receipt.auth.editor.mode, "legacy_boolean");
  assert(receipt.warnings.some((warning) => warning.code === "legacy_editor_ready"));
});

test("missing production writer blocks before production", async (context) => {
  const data = fixture();
  context.after(() => fs.rmSync(data.root, { recursive: true, force: true }));
  const receipt = await runPreflight(
    {
      account: "Example Co",
      operator: "trey",
      opportunityOwner: "trey",
      package: data.handoff,
      deck: data.deck,
      meetingMatchConfirmed: true,
      noAccountExamples: true,
      writer: path.join(data.root, "missing-writer.js"),
      outputRepo: data.root,
      budgetSeconds: 30,
    },
    { env: { FOLLOZE_ACCESS_TOKEN: "redacted-test-token" } }
  );
  assert.equal(receipt.ready, false);
  assert(receipt.blockers.some((blocker) => blocker.code === "writer_missing"));
});
