#!/usr/bin/env python3
"""Build a deterministic, cache-free ZIP of this skill for teammate handoff."""

from __future__ import annotations

import argparse
import hashlib
import stat
import subprocess
import zipfile
from pathlib import Path


ARCHIVE_ROOT = "folloze-digital-deal-room-internal"
EXCLUDED_NAMES = {".DS_Store", "__pycache__"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
ZIP_TIMESTAMP = (2026, 8, 4, 0, 0, 0)
REQUIRED_RELEASE_PATHS = (
    "scripts/fast_path_writer.js",
    "scripts/fast_path_writer.test.js",
    "scripts/benchmark_fast_path.js",
    "scripts/benchmark_fast_path.test.js",
    "scripts/clip_call_recording.test.js",
    "scripts/fast_path_preflight.js",
    "scripts/fast_path_orchestrator.js",
    "scripts/verify_deal_room_receipt.js",
    "scripts/schemas/deal_room_write_spec.schema.json",
    "references/production-writer-contract.md",
    "references/fast-path-acceptance.md",
)


def included_files(skill_root: Path) -> list[Path]:
    files: list[Path] = []
    for path in skill_root.rglob("*"):
        relative = path.relative_to(skill_root)
        if any(part in EXCLUDED_NAMES for part in relative.parts):
            continue
        if path.is_file() and path.suffix not in EXCLUDED_SUFFIXES:
            files.append(path)
    return sorted(files, key=lambda item: item.relative_to(skill_root).as_posix())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_release(skill_root: Path) -> None:
    missing = [relative for relative in REQUIRED_RELEASE_PATHS if not (skill_root / relative).is_file()]
    if missing:
        raise SystemExit(f"Release validation failed; missing required files: {', '.join(missing)}")

    scripts = skill_root / "scripts"
    javascript = sorted(scripts.rglob("*.js"))
    for source in javascript:
        completed = subprocess.run(
            ["node", "--check", str(source)],
            cwd=skill_root,
            capture_output=True,
            text=True,
            check=False,
        )
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout).strip()
            raise SystemExit(f"Release validation failed for {source.name}: {detail}")

    tests = sorted(scripts.glob("*.test.js"))
    completed = subprocess.run(
        ["node", "--test", *map(str, tests)],
        cwd=skill_root,
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()
        raise SystemExit(f"Release tests failed:\n{detail}")

    capabilities = subprocess.run(
        ["node", str(scripts / "fast_path_writer.js"), "capabilities"],
        cwd=skill_root,
        capture_output=True,
        text=True,
        check=False,
    )
    if capabilities.returncode != 0 or "DSR_WRITER_CAPABILITIES_JSON_END" not in capabilities.stdout:
        detail = (capabilities.stderr or capabilities.stdout).strip()
        raise SystemExit(f"Writer capabilities validation failed: {detail}")


def build(skill_root: Path, output: Path) -> dict[str, object]:
    skill_root = skill_root.resolve()
    output = output.resolve()
    if not (skill_root / "SKILL.md").is_file():
        raise SystemExit(f"Skill root has no SKILL.md: {skill_root}")
    validate_release(skill_root)
    if output.exists():
        raise SystemExit(f"Refusing to overwrite existing package: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)

    files = included_files(skill_root)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source in files:
            relative = source.relative_to(skill_root).as_posix()
            info = zipfile.ZipInfo(f"{ARCHIVE_ROOT}/{relative}", date_time=ZIP_TIMESTAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            permissions = 0o755 if source.stat().st_mode & stat.S_IXUSR else 0o644
            info.external_attr = (stat.S_IFREG | permissions) << 16
            archive.writestr(info, source.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    return {
        "package": str(output),
        "sha256": sha256(output),
        "file_count": len(files),
        "archive_root": ARCHIVE_ROOT,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--skill-root",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Defaults to the skill directory containing this script.",
    )
    args = parser.parse_args()
    receipt = build(args.skill_root, args.output)
    print(f"package={receipt['package']}")
    print(f"sha256={receipt['sha256']}")
    print(f"file_count={receipt['file_count']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
