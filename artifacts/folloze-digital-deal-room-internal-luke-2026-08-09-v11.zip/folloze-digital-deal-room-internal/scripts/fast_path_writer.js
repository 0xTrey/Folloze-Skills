#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { FollozeClient } = require("./lib/folloze_client.js");
const { WriterState } = require("./lib/writer_state.js");
const { specHash, validateWriteSpec } = require("./lib/writer_spec.js");
const { personalizeConfig, recomputeHash, requiredWidgets, stripTransientScripts, WIDGETS } = require("./lib/template_248623.js");
const { BoardInventory, configureExampleCarousel, ensureAssetItem, ensureExampleItem, readCategories } = require("./lib/content_items.js");

const CAPABILITIES = Object.freeze({
  schema_version: "1.0",
  writer: "folloze-native-deal-room-writer",
  writer_version: "1.2.0",
  ready: true,
  dry_run_default: true,
  capabilities: [
    "copy_template",
    "upload_assets",
    "save_config",
    "publish",
    "vanity",
    "receipt",
    "idempotent_resume",
    "template_248623_guards",
  ],
  supported_template_ids: [248623],
  supported_operations: [
    "exact_profile_and_organization_identity",
    "template_audit",
    "template_copy_with_immediate_checkpoint",
    "metadata_and_vanity",
    "concurrent_file_and_tile_uploads",
    "native_essentials_items",
    "optional_recording_with_order_form_fallback",
    "native_example_items_and_curated_order",
    "existing_board_example_append",
    "allowlisted_value_text_mutation",
    "roi_byte_identity",
    "designer_hash_save_and_readback",
    "publish_gating_and_readback",
    "idempotent_resume_state",
  ],
  authorization: {
    apply_flag_required: true,
    confirm_run_id_required: true,
    allow_external_writes_required: true,
    credentials_in_spec_allowed: false,
  },
  output_marker: "DSR_WRITER_JSON_END",
});

function sleepDefault(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function activeConfig(data) {
  return data?.unpublished_config || data?.published_config || null;
}

function findBoardId(value, templateId) {
  if (!value || typeof value !== "object") return null;
  const candidates = [
    value.board_id,
    value.id,
    value.board?.id,
    value.data?.board_id,
    value.data?.board?.id,
    value.data?.id,
  ];
  for (const candidate of candidates) {
    if (Number.isInteger(candidate) && candidate !== templateId) return candidate;
  }
  return null;
}

function findGuid(value) {
  return value?.guid || value?.copy_guid || value?.job_guid || value?.data?.guid || null;
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function publicLink(meta) {
  return meta?.public_link || meta?.embedded_board_link?.replace(/\?token=.*/, "") || null;
}

async function copyTemplate(client, templateId, sleep, options = {}) {
  const budgetMs = options.budgetMs || 20_000;
  const delays = [250, 500, 1_000, 2_000];
  let waitedMs = 0;
  let guid = null;
  for (let attempt = 1; ; attempt += 1) {
    const payload = { item_ids: [], copy_customizations: true, copy_all_items: true };
    if (guid) payload.guid = guid;
    const response = await client.request(`/api/v1/boards/${templateId}/copy`, "POST", payload);
    const boardId = findBoardId(response.data, templateId);
    if (boardId) return { board_id: boardId, copy_status: response.status, attempts: attempt };
    guid = findGuid(response.data);
    if (!guid && response.status !== 206) {
      const responseShape = JSON.stringify(response.data, (key, nested) =>
        /token|secret|password|cookie|authorization/i.test(key) ? "[REDACTED]" : nested
      ).slice(0, 800);
      throw new Error(`Template copy returned neither a board ID nor a polling GUID (status ${response.status}; response ${responseShape}).`);
    }
    const delay = delays[Math.min(attempt - 1, delays.length - 1)];
    if (waitedMs + delay > budgetMs) break;
    await sleep(delay);
    waitedMs += delay;
  }
  throw new Error(`Template copy did not resolve inside its ${budgetMs}ms production budget.`);
}

async function pollItem(client, itemId, predicate, sleep) {
  const delays = [0, 200, 400, 800];
  let item = null;
  for (const delay of delays) {
    if (delay) await sleep(delay);
    item = (await client.request(`/api/v1/items/${itemId}`)).data;
    if (predicate(item)) return item;
  }
  return item;
}

async function runWriter(input, options = {}) {
  const clock = options.clock || (() => Date.now());
  const sleep = options.sleep || sleepDefault;
  const started = clock();
  const spec = validateWriteSpec(input, { requireFiles: options.requireFiles !== false });
  const appendExamples = spec.operation === "append_examples";
  const hash = specHash(spec);
  const inheritedRunId = options.orchestratorRunId || options.environment?.DSR_RUN_ID || process.env.DSR_RUN_ID || null;
  if (inheritedRunId && inheritedRunId !== spec.run_id) throw new Error("Inherited DSR_RUN_ID does not match the write specification run_id.");
  const orchestratorHash = options.orchestratorSpecSha256 || options.environment?.DSR_SPEC_SHA256 || process.env.DSR_SPEC_SHA256 || hash;
  if (!options.apply) {
    return {
      schema_version: "1.0",
      writer_version: CAPABILITIES.writer_version,
      mode: "dry_run",
      ready: true,
      run_id: spec.run_id,
      spec_sha256: orchestratorHash,
      write_spec_sha256: hash,
      template: spec.target.template,
      target: { base_url: spec.target.base_url, profile: spec.target.profile, organization_id: spec.target.organization_id },
      operation: spec.operation,
      plan: appendExamples
        ? ["identity", "template_audit", "existing_board_audit", "tile_uploads", "examples", "config", "publish", "readback"]
        : ["identity", "template_audit", "template_copy", "metadata", "vanity", "uploads", "config", "essentials", "examples", "publish", "readback"],
      publish_requested: spec.board.publish,
      external_writes_performed: false,
      elapsed_ms: clock() - started,
    };
  }
  if (options.confirmRunId !== spec.run_id) throw new Error("--confirm-run-id must exactly match the specification run_id.");
  if (!options.allowExternalWrites) throw new Error("--allow-external-writes is required for apply mode.");
  if (!options.statePath) throw new Error("--state is required for apply mode so every mutation is resumable.");

  const state = options.state || new WriterState(options.statePath, spec.run_id, hash, clock);
  const client = options.client || new FollozeClient({
    baseUrl: spec.target.base_url,
    profile: spec.target.profile,
    fetchImpl: options.fetchImpl,
    environment: options.environment,
  });
  if (client.identity.organization_id !== spec.target.organization_id) {
    throw new Error(`Authenticated organization ${client.identity.organization_id} does not match explicit organization ${spec.target.organization_id}.`);
  }
  await state.checkpoint("identity", {
    profile: spec.target.profile,
    organization_id: client.identity.organization_id,
    subject: client.identity.subject,
    issuer: client.identity.issuer,
  });

  let templateReceipt = state.get("template_audit")?.receipt;
  let templateRoiContent = null;
  if (!templateReceipt) {
    const [metaResponse, configResponse] = await Promise.all([
      client.request(`/prism/${spec.target.template.id}`),
      client.request(`/api/v1/boards/${spec.target.template.id}/config`),
    ]);
    const meta = metaResponse.data;
    const config = activeConfig(configResponse.data);
    if (meta.id !== spec.target.template.id || meta.name !== spec.target.template.name || meta.is_template !== true) {
      throw new Error("Template identity readback failed.");
    }
    const widgets = requiredWidgets(config);
    templateRoiContent = widgets[WIDGETS.roi].data.content;
    templateReceipt = await state.checkpoint("template_audit", {
      id: meta.id,
      name: meta.name,
      is_template: meta.is_template,
      roi_sha256: sha256(templateRoiContent),
    });
  } else {
    const config = activeConfig((await client.request(`/api/v1/boards/${spec.target.template.id}/config`)).data);
    templateRoiContent = requiredWidgets(config)[WIDGETS.roi].data.content;
    if (sha256(templateRoiContent) !== templateReceipt.roi_sha256) throw new Error("Template ROI changed since the resumable run began.");
  }

  let boardId;
  if (appendExamples) {
    boardId = spec.board.existing_id;
  } else {
    let copyReceipt = state.get("template_copy")?.receipt;
    if (!copyReceipt) {
      copyReceipt = await copyTemplate(client, spec.target.template.id, sleep);
      await state.checkpoint("template_copy", copyReceipt);
    }
    boardId = copyReceipt.board_id;
  }
  const copiedMeta = (await client.request(`/prism/${boardId}`)).data;
  if (copiedMeta.id !== boardId || copiedMeta.is_template !== false) throw new Error("Copied-board identity readback failed.");
  if (appendExamples && (copiedMeta.name !== spec.board.name || copiedMeta.slug !== spec.board.slug)) {
    throw new Error("Existing-board name or vanity readback does not match the append specification.");
  }
  await state.checkpoint(appendExamples ? "existing_board_audit" : "copied_board_audit", {
    board_id: boardId,
    is_template: false,
    mode: spec.operation,
  });

  if (appendExamples) {
    await state.checkpoint("metadata", { name: copiedMeta.name, verified_only: true });
    await state.checkpoint("vanity", { slug: copiedMeta.slug, verified_only: true });
  } else if (!state.has("metadata")) {
    await client.request(`/prism/${boardId}`, "PUT", {
      board: { name: spec.board.name, description: spec.board.description, is_public: false },
    });
    await state.checkpoint("metadata", { name: spec.board.name, is_public: false });
  }
  if (!appendExamples && !state.has("vanity")) {
    await client.request(`/api/v1/boards/${boardId}/slugs/validations`, "POST", { slug: spec.board.slug });
    const vanity = await client.request(`/api/v1/boards/${boardId}/slugs`, "POST", { slug: spec.board.slug });
    await state.checkpoint("vanity", { slug: vanity.data?.slug || spec.board.slug });
  }

  const essentialKinds = appendExamples ? [] : ["recording", "deck", "order_form"].filter((kind) => spec.assets[kind]);
  const uploadJobs = [
    ...essentialKinds.flatMap((kind) => [
      [`${kind}_file`, spec.assets[kind].path, ["deck", "order_form"].includes(kind) ? "pdf" : undefined],
      [`${kind}_cover`, spec.assets[kind].cover_path, "image"],
    ]),
    ...spec.examples.map((example, index) => [`example_${index}_tile`, example.tile_path, "image"]),
  ];
  const uploadReceipts = Object.fromEntries(await Promise.all(uploadJobs.map(async ([name, file, type]) => {
    const operation = `upload.${name}`;
    let receipt = state.get(operation)?.receipt;
    if (!receipt) {
      const uploaded = await client.upload(file, type);
      receipt = await state.checkpoint(operation, uploaded);
    }
    return [name, receipt];
  })));

  const categories = await readCategories(client, boardId);
  const inventory = await BoardInventory.load(client, boardId);
  const essentialsCategory = categories.find((category) => category.name === "Essentials");
  const examplesCategory = categories.find((category) => category.name === "Example Boards");
  if (!essentialsCategory || !examplesCategory) throw new Error("Copied board is missing Essentials or Example Boards category.");

  const essentialReceipts = Object.fromEntries(await Promise.all(essentialKinds.map(async (kind) => {
    const operation = `essential.${kind}`;
    let receipt = state.get(operation)?.receipt;
    if (!receipt) {
      receipt = await ensureAssetItem(client, {
        boardId,
        organizationId: spec.target.organization_id,
        categoryId: essentialsCategory.id,
        kind,
        asset: spec.assets[kind],
        fileUpload: uploadReceipts[`${kind}_file`],
        coverUpload: uploadReceipts[`${kind}_cover`],
        inventory,
      });
      await state.checkpoint(operation, receipt);
    }
    return [kind, receipt];
  })));

  const exampleReceipts = await Promise.all(spec.examples.map(async (example, index) => {
    const operation = `example.${index}`;
    let receipt = state.get(operation)?.receipt;
    if (!receipt) {
      receipt = await ensureExampleItem(client, {
        boardId,
        categoryId: examplesCategory.id,
        example,
        tileUpload: uploadReceipts[`example_${index}_tile`],
        inventory,
      });
      await state.checkpoint(operation, receipt);
    }
    return receipt;
  }));

  let configReceipt = state.get("config_save")?.receipt;
  if (!configReceipt) {
    const response = await client.request(`/api/v1/boards/${boardId}/config`);
    const config = activeConfig(response.data);
    const beforeWidgets = requiredWidgets(config);
    const beforeValueContent = beforeWidgets[WIDGETS.value].data.content;
    const personalization = appendExamples
      ? { config, value_edit_count: 0 }
      : personalizeConfig(config, spec, templateRoiContent, clock());
    const carousel = await configureExampleCarousel(
      client,
      boardId,
      exampleReceipts.map((entry) => entry.id),
      personalization.config,
      inventory
    );
    stripTransientScripts(carousel.config);
    const afterWidgets = requiredWidgets(carousel.config);
    const valueWidgetByteIdentical = afterWidgets[WIDGETS.value].data.content === beforeValueContent;
    if (appendExamples && !valueWidgetByteIdentical) throw new Error("Value widget changed during example-only append.");
    if (afterWidgets[WIDGETS.roi].data.content !== templateRoiContent) throw new Error("ROI changed during config preparation.");
    const savedHash = recomputeHash(carousel.config, clock());
    const save = await client.request(`/api/v1/boards/${boardId}/config`, "PUT", { config: carousel.config });
    if (![200, 201, 208].includes(save.status)) throw new Error(`Config save returned ${save.status}.`);
    const readback = activeConfig((await client.request(`/api/v1/boards/${boardId}/config`)).data);
    if (readback?.meta?.newHash !== savedHash) throw new Error("Final single-save config hash did not persist on readback.");
    if (readback.pages.default.widgets[WIDGETS.roi].data.content !== templateRoiContent) throw new Error("ROI byte identity failed after config save.");
    configReceipt = await state.checkpoint("config_save", {
      saved_hash: savedHash,
      value_edit_count: personalization.value_edit_count,
      value_widget_byte_identical: valueWidgetByteIdentical,
      roi_byte_identical: true,
      save_status: save.status,
      carousel_item_ids: carousel.item_ids,
      baseline_titles: carousel.baseline_titles,
    });
  }

  await inventory.refresh();
  for (const kind of essentialKinds) {
    let item = inventory.get(essentialReceipts[kind].id);
    const expected = essentialReceipts[kind];
    if (item?.title !== expected.title || !item?.categories_ids?.includes(expected.category_id)) {
      throw new Error(`Final ${kind} item readback does not match its checkpoint.`);
    }
    if (item?.image?.url !== expected.image_url) {
      await client.request(`/api/v1/items/content_items/${item.content_item_id}`, "PUT", {
        id: item.content_item_id,
        title: expected.title,
        image: { url: expected.image_url, fit: "cover" },
      });
      await client.request(`/api/v1/items/${item.id}`, "PUT", {
        id: item.id,
        board_id: boardId,
        title: expected.title,
        categories_ids: [expected.category_id],
        image: { url: expected.image_url, fit: "cover" },
      });
      item = await pollItem(client, item.id, (candidate) => candidate?.image?.url === expected.image_url, sleep);
      if (item?.image?.url !== expected.image_url) throw new Error(`Final ${kind} tile image did not persist before publish.`);
    }
  }
  exampleReceipts.forEach((expected) => {
    const item = inventory.get(expected.id);
    if (item?.title !== expected.title || item?.url !== expected.url || item?.image?.url !== expected.image_url || !item?.categories_ids?.includes(expected.category_id)) {
      throw new Error(`Final example item ${expected.id} readback does not match its checkpoint.`);
    }
  });

  const publishReady = Object.values(essentialReceipts).every((entry) => entry.ready)
    && exampleReceipts.every((entry) => entry.ready)
    && configReceipt.roi_byte_identical
    && (!appendExamples || configReceipt.value_widget_byte_identical);
  let publishReceipt = state.get("publish")?.receipt;
  if (!publishReceipt) {
    if (spec.board.publish) {
      if (!publishReady) throw new Error("Publish gate failed: required assets, examples, or config evidence is incomplete.");
      await client.request(`/prism/${boardId}`, "PUT", {
        board: { name: spec.board.name, description: spec.board.description, is_public: true },
      });
      const published = await client.request(`/api/v1/boards/${boardId}/publish`, "POST");
      publishReceipt = { requested: true, performed: true, status: published.status };
    } else {
      publishReceipt = { requested: false, performed: false, status: null };
    }
    await state.checkpoint("publish", publishReceipt);
  }

  const [metaResponse, configResponse] = await Promise.all([
    client.request(`/prism/${boardId}`),
    client.request(`/api/v1/boards/${boardId}/config`),
  ]);
  const meta = metaResponse.data;
  const unpublished = configResponse.data?.unpublished_config;
  const published = configResponse.data?.published_config;
  const finalConfig = publishReceipt.performed ? published : unpublished;
  const finalWidgets = requiredWidgets(finalConfig);
  const roiMatches = finalWidgets[WIDGETS.roi].data.content === templateRoiContent;
  const hashesMatch = Boolean(unpublished?.meta?.newHash && published?.meta?.newHash && unpublished.meta.newHash === published.meta.newHash);
  const savedHashMatches = unpublished?.meta?.newHash === configReceipt.saved_hash;
  const verifiedPublicLink = publicLink(meta);
  const verifiedPublicState = Boolean(meta.is_public ?? (meta.has_published_version && verifiedPublicLink));
  if (!savedHashMatches) throw new Error("Final config readback no longer matches the checkpointed saved hash.");
  if (publishReceipt.performed && (!verifiedPublicState || !meta.has_published_version || !hashesMatch || !verifiedPublicLink)) throw new Error("Published board readback gate failed.");
  if (!roiMatches) throw new Error("Final ROI byte-identity gate failed.");

  const receipt = {
    schema_version: "1.0",
    writer_version: CAPABILITIES.writer_version,
    mode: "apply",
    operation: spec.operation,
    ready: publishReceipt.performed ? true : publishReady,
    run_id: spec.run_id,
    spec_sha256: orchestratorHash,
    write_spec_sha256: hash,
    target: { profile: spec.target.profile, organization_id: spec.target.organization_id },
    template: { id: templateReceipt.id, name: templateReceipt.name, is_template: true },
    board: {
      id: boardId,
      name: meta.name,
      is_template: meta.is_template,
      is_public: verifiedPublicState,
      has_published_version: Boolean(meta.has_published_version),
      slug: meta.slug || spec.board.slug,
      designer_url: `${spec.target.base_url}/app/board/${boardId}/designer`,
      public_url: publishReceipt.performed ? verifiedPublicLink : null,
    },
    config: {
      personalized_hash: configReceipt.saved_hash,
      final_unpublished_hash: unpublished?.meta?.newHash || null,
      final_published_hash: published?.meta?.newHash || null,
      hashes_match: hashesMatch,
      saved_hash_matches_checkpoint: savedHashMatches,
      value_html_diff_allowlist_passed: appendExamples
        ? configReceipt.value_widget_byte_identical === true
        : configReceipt.value_edit_count === 17,
      roi_byte_identical_to_template: roiMatches,
    },
    essentials: essentialReceipts,
    examples: { added: exampleReceipts, baseline_preserved: true, carousel_hash: configReceipt.saved_hash },
    publish: publishReceipt,
    resumability: { state_path: path.resolve(options.statePath), completed_operations: Object.keys(state.data.operations).length },
    performance: {
      elapsed_ms: clock() - started,
      ...(typeof client.performanceSummary === "function" ? client.performanceSummary() : { api_calls: client.callCount }),
    },
    external_writes_performed: true,
  };
  await state.checkpoint("final_readback", {
    board_id: boardId,
    published: publishReceipt.performed,
    unpublished_hash: receipt.config.final_unpublished_hash,
    published_hash: receipt.config.final_published_hash,
    roi_byte_identical: roiMatches,
  });
  return receipt;
}

function parseArgs(argv) {
  const args = { command: "run", apply: false, allowExternalWrites: false };
  const values = [...argv];
  if (values[0] === "capabilities" || values[0] === "--capabilities") {
    args.command = "capabilities";
    values.shift();
  } else if (values[0] === "plan") {
    args.command = "run";
    values.shift();
  } else if (values[0] === "apply") {
    args.command = "run";
    args.apply = true;
    values.shift();
  }
  while (values.length) {
    const token = values.shift();
    if (token === "--apply") args.apply = true;
    else if (token === "--allow-external-writes") args.allowExternalWrites = true;
    else if (["--spec", "--state", "--confirm-run-id", "--receipt"].includes(token)) {
      const value = values.shift();
      if (!value) throw new Error(`${token} requires a value.`);
      args[{ "--spec": "specPath", "--state": "statePath", "--confirm-run-id": "confirmRunId", "--receipt": "receiptPath" }[token]] = value;
    } else throw new Error(`Unknown argument: ${token}`);
  }
  return args;
}

function emit(receipt) {
  process.stdout.write(`DSR_WRITER_JSON_BEGIN\n${JSON.stringify(receipt)}\nDSR_WRITER_JSON_END\n`);
}

function emitCapabilities(receipt) {
  process.stdout.write(`DSR_WRITER_CAPABILITIES_JSON_BEGIN\n${JSON.stringify(receipt)}\nDSR_WRITER_CAPABILITIES_JSON_END\n`);
}

function writeReceipt(filePath, receipt) {
  const absolute = path.resolve(filePath);
  fs.mkdirSync(path.dirname(absolute), { recursive: true });
  const temporary = `${absolute}.${process.pid}.tmp`;
  fs.writeFileSync(temporary, `${JSON.stringify(receipt, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(temporary, absolute);
}

async function main(argv = process.argv.slice(2)) {
  const args = parseArgs(argv);
  if (args.command === "capabilities") {
    emitCapabilities(CAPABILITIES);
    return CAPABILITIES;
  }
  if (!args.specPath) throw new Error("--spec is required.");
  const input = JSON.parse(fs.readFileSync(path.resolve(args.specPath), "utf8"));
  const receipt = await runWriter(input, args);
  if (args.receiptPath) writeReceipt(args.receiptPath, receipt);
  emit(receipt);
  return receipt;
}

if (require.main === module) {
  main().catch((error) => {
    emit({ schema_version: "1.0", writer_version: CAPABILITIES.writer_version, ready: false, error: { code: error.code || "writer_failed", message: error.message } });
    process.exitCode = 1;
  });
}

module.exports = { CAPABILITIES, copyTemplate, findBoardId, main, parseArgs, runWriter };
